#!/bin/bash

ffplay musiques/antoni.mp3
