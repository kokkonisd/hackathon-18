print("Je gère les enceintes !")
